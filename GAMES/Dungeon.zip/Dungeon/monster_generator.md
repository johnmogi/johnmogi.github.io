monster{
    name: '',
    type: '',
    clan: '',
    
}