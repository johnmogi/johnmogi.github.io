
function diceRoll(num){
 return Math.floor(Math.random() * num);
}

console.log(diceRoll(6))
console.log(diceRoll(10))
console.log(diceRoll(20))

