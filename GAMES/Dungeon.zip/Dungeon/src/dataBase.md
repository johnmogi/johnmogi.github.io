has chosen to use strapi with mongo

cons : no need to worry about inner data bloat
cons - simple order of data from 3 control points:
graphql
strapi

yarn create strapi-app Server

dungeon
mysql

sudo yarn develop
Dunge0n master

export
