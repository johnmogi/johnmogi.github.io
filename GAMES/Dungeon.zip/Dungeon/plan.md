the Dungeon is a multiplayer game that aids basic D & D

a dungeon is generated from an array of sqaure

a path is constructed between all rooms
all paths are open but a door can be locked | trap

monster generator

equipment

--- Dungeon generator ---


tech issue - the whole cors situation.

https://javascript.info/fetch-crossorigin

bottom line: 
if not working with mimic server- no cors allowed- use local json.