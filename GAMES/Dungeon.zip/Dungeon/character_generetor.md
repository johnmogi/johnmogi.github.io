characters :{
    name: '',
    type: '',
    age: '',
    proffession: '',
    life: '',
    magic: '',
    strength: '',
    rank: '',
    experience: '',
    equipment: '',
    limitations: '',
    weakness: ''
}

data pool:

names:
first name (male):
{
'og', 'zorg', 'bran', 'bill', 'john', 'danny', 'sam', 'skip', 'koko', 'sal', 'roger', 'roe',
'simson', 'soso', 'jany'
}
first name (female):
{
    'ruth', 'gal', 'cinthya', 'brolla', 'georgie', 'hilda', 'balbala', 'loney', 'merka'
    , 'jenny', 'sara'
}
last name:
{
    'banana', 'cohen', 'lashala', 'sonson', 'rara', 'moglior', 'radibia', 'birdala', 'poka', 'rigalux'
}
types:
{
    'human', 'orc', 'elf', 'hobbit', 'dwarf', 'undead', 'lizard', 'snake', 'bear'
    'cat', 'dino', 'cantaur', 'mech'
}
proffesion:
{
  'magician', 'witch', 'warrior', 'monk' , 'thief', 'bard', 'pirate', 'acrobat'
}


   "firstName": ["og", "zorg", "bran", "bill", "john", "danny", "sam", "skip", "koko", "sal", "roger", "roe",
      "simson", "soso", "jany"
   ]


locations:
'forest', 'swamp', 'mountains', 'hills', 'volcano', 'islands', 'clouds', 'castle', 'cliffs', 'jungle', 'old market', 'desert', 'tunnels', 'village', 'festival', 'carnival', 'circus', 'arena', 'wagon caravan', 'military base', 'monastery', 'lake', 'beach' , 'river' 