module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'e9146e69-9e05-4e53-aeaf-4ee1f41aafc6'
};