a mermaid that allways wanted to get to shore

her people - sea monsters
chaines victims and drags them into the deep

----------------------

the twisted forest

a swamp a lake in the green 


----------------------

a swamp created on a lake
lizard dragons defilled the lake for their habitat
wants to take over the lake


